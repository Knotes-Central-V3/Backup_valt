# Security Policy

## Supported Versions

project that are currently being supported with security updates.

| Version | Supported          |
| ------- | ------------------ |
| [2.1.x](https://developer1010x.github.io/KnotesCentral/)   | :white_check_mark: |
| [1.0.x ](https://developer1100x.github.io/KnotesCentralV1.0/)  | :x:                |





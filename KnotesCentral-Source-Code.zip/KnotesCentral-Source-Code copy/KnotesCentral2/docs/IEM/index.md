# Industrial Engineering and Management

## [Home](../main/index.md) | [Updates](../main/updates.md) | [Credits](../main/credits.md)

---

# Course Material

| Year            | Link                                                                                              |
| --------------------------- | ------------------------------------------------------------------------------------------------- |
| Second Year                 | [Link](https://drive.google.com/drive/folders/1MIbjGqKrQvNPF5RGXV9kgP7dHWuVE_gL?usp=sharing)   |
| Third Year                  | [Link](https://drive.google.com/drive/folders/1M0cBC0KTpMwFfV4DSJgdA0oIf-GdWvvp?usp=sharing)   |
| Fourth Year                 | [Link](https://drive.google.com/drive/folders/1Cri-Fx-NBGKVns2PIoq6GMeiw7Uo5QM6?usp=sharing)   |

___



<p style="color:red; font-size:small;">
  Login Via RVCE Mail ID to Access the Notes !!
</p>

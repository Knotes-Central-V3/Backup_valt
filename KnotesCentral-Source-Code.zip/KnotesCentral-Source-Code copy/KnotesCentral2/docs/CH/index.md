

# Chemical Engineering

## [Home](../main/index.md) | [Updates](../main/updates.md) | [Credits](../main/credits.md)

---

# Course Material

| Year            | Link                                                                                              |
| --------------------------- | ------------------------------------------------------------------------------------------------- |
| Second Year                 | [Link](https://drive.google.com/drive/folders/1fGS2ciz-PRoOyhX2OX0EuHpK5gVVRKUT?usp=sharing)   |
| Third Year                  | [Link](https://drive.google.com/drive/folders/11uFVZ58JtfVP1qsSVAE26W6iO8Oh5OBb?usp=sharing)   |
| Fourth Year                 | [Link](https://drive.google.com/drive/folders/1Lp8zA5Q9J6oT7VvX2Y3wQfW9Z0rL9dC8?usp=sharing)   |

___





<p style="color:red; font-size:small;">
  Login Via RVCE Mail ID to Access the Notes!!
</p>

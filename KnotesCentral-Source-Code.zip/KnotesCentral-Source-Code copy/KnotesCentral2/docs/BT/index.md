# Biotechnology

## [Home](../main/index.md) | [Updates](../main/updates.md) | [Credits](../main/credits.md)

---

# Course Material

| Year            | Link                                                                                              |
| --------------------------- | ------------------------------------------------------------------------------------------------- |
| Second Year                 | [Link](https://drive.google.com/drive/folders/151ZzTqP66Bghw2Ktcc6vFgUDCLn4fPu7?usp=sharing)   |
| Third Year                  | [Link](https://drive.google.com/drive/folders/1DJKcWxjZ18y6WAY3jCf7OfcrL5UuDDF_?usp=sharing)   |
| Fourth Year                 | [Link](https://drive.google.com/drive/folders/1QmB7ZcL2J7xX9y8rP5K3V6Y0Z8nFfWc9?usp=sharing)   |

___
<p style="color:red; font-size:small;">
  Login Via RVCE Mail ID to Access the Notes!!
</p>





# Civil Engineering

## [Home](../main/index.md) | [Updates](../main/updates.md) | [Credits](../main/credits.md)

---

# Course Material

| Year            | Link                                                                                              |
| --------------------------- | ------------------------------------------------------------------------------------------------- |
| Second Year                 | [Link](https://drive.google.com/drive/folders/1aZqB6S-abDky66oRh5DWDa75QpRHsP70?usp=sharing)   |
| Third Year                  | [Link](https://drive.google.com/drive/folders/1pxLXq3ZpJ0-pyATadSQDviJucnFpOp6X?usp=sharing)   |
| Fourth Year                 | [Link](https://drive.google.com/drive/folders/1KkW8CpEJ2vZ3n8yBkx7P7PqF9H0mFfT3?usp=sharing)   |

___


<p style="color:red; font-size:small;">
  Login Via RVCE Mail ID to Access the Notes!!
</p>

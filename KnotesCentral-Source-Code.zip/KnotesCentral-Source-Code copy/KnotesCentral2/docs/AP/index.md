# AICTE_ACTIVITY_POINTS_REPO

## [Home](../main/index.md) | [Updates](../main/updates.md) | [Credits](../main/credits.md)

---

#  Material
<p style="color:red; font-size:small;">
  This Page is still in Developement please co operate
</p>

| Year            | Link                                                                                              |
| --------------------------- | ------------------------------------------------------------------------------------------------- |
|NCC|
| NSS             | [Link]()   |
| Rotaract                 | [Link]()   |
|Art of Living               | [Link]()   |
|Acclerate ||
|Coding Club||
|Some other club||
|Student F1 ||
|Aerospace club||
|Robotics||
|Kannada Sangha||

___

<p style="color:red; font-size:small;">
   Login Via RVCE Mail ID to Access the Notes!!
</p>

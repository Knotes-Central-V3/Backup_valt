# Physics Cycle

## [Home](../main/index.md) | [Updates](../main/updates.md) | [Credits](../main/credits.md)

---

# Course Material

- P cycle is common for all branches in the first year.
  Please find the course material for the Physics Cycle below:

| Topic                | Link                                                     |
| -------------------- | -------------------------------------------------------- |
|Physics Cycle Notes |  [Link](https://drive.google.com/drive/folders/1EHqT2hTuaADcG-q5SKuMCY75scJP4AOH?usp=sharing)|
___

# Course Material

| Topic                | Link                                                     |
| -------------------- | -------------------------------------------------------- |
| RVCE Physics Dept Website | [Link](https://physicsrvce.wordpress.com)                |
| Physics Dept  Notes        | [Link](https://physicsrvce.wordpress.com/physics-notes/) |

# CSE and Allied Courses

## [Home](../main/index.md) | [Updates](../main/updates.md) | [Credits](../main/credits.md)

---

# Lab Material

| Lab Program       | Link                                                                      |Link2 |
| ----------------- | ------------------------------------------------------------------------- |------|
| Java Lab          | [GitHub](https://github.com/KTS-o7/Java_OOPS_Codes)                       |  NA    |
| DSA Lab           | [GitHub](https://github.com/KTS-o7/Third_sem_Codes)                       |  NA  |
| PIC Lab           | [GitHub](https://github.com/KTS-o7/PIC_Lab_programs_RVCE)                 |  NA   |
| DAA Lab           | [GitHub](https://github.com/KTS-o7/LAB_Programs_Rvce_2ndYear.git)         |   NA   |
| CD Lab            | [GitHub](https://github.com/KTS-o7/Compiler-Design)                       |[GitHub](https://github.com/Abhishek0R/Compiler-Design-Lab-Programs)|
| OS Lab            | [GitHub](https://github.com/Developer1100x/RVCE_Operating-System_LAB)     |    NA  |
| Idea Lab          | [GitHub](https://github.com/Developer1100x/RVCE_Idea_lab_2021B)           |   NA   |
| NPS Lab 18 Scheme | [GitHub](https://github.com/18praneeth/RVCE-5th-Sem-CSE-lab-programs-NPS) |    NA  |
|PADP Lab 18 and 21 Scheme|[GitHub_18](https://github.com/18praneeth/RVCE-7th-Sem-CSE-lab-programs-CGVR-PADP/tree/main/PADP)|[GitHub_21 Scheme](https://github.com/Shreyas-Shankar155/PADPLab)|

---

Back to [CSE](./index.md)

### Shoutout to the core contributor

> [KTS-o7](https://github.com/KTS-o7)

> [Developer1010x](https://github.com/Developer1010x)

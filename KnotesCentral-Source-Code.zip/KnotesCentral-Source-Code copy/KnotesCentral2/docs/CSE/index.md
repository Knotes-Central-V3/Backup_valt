# Computer Science and Engineering 

## [Home](../main/index.md) | [Updates](../main/updates.md) | [Credits](../main/credits.md)

---

# Course Material

| Year            | Link                                                                                              |
| --------------------------- | ------------------------------------------------------------------------------------------------- |
| Second Year                 | [Link](https://drive.google.com/drive/folders/1gNXa1BkKYSwut8tnHifh3gFojzYWpl9Z?usp=sharing)   |
| Third Year                  | [Link](https://drive.google.com/drive/folders/1D7v0gPbPlS5Yj3T1LLNrWCtLyFR0CLiJ?usp=sharing)   |
| Fourth Year                 | [Link](https://drive.google.com/drive/folders/1ow4-_cxSb2pbSakJtdMFr0cR7nISMmDE?usp=sharing)   |

___

## Lab Material

[Link to lab](./labs.md)

---

## Miscellaneous

- Some useful site - [Link](https://juggadnauts.notion.site/Juggadnauts-d42b335ffc7d4909bcc2d14311e443f0)







___
<p style="color:red; font-size:small;">
  Login Via RVCE Mail ID to Access the Notes!!
</p>

# Credits

# [Home](./index.md) | [About](./about.md) | [Updates](./updates.md)

---

### This project was made possible by the efforts of the following individuals who generously shared their department notes and contributed to helping fellow classmates and beyond.

---

## **DEVELOPERS**

| Name                                          | Dept | Year      |
| --------------------------------------------- | ---- | --------- |
| [S Prajwall Narayana](https://developer1010x.github.io/S_Prajwall_Narayana/) | CSE  | 2021-2025 |
| [Krishnatejaswi S](https://kts-o7.github.io/) | CSE  | 2021-2025 |

---

## **CONTRIBUTORS**

| Name                                          | Dept | Year      |
| --------------------------------------------- | ---- | --------- |
| Arpitha R S                                   | BT   | 2020-2024 |
| Harish Narayan                                | CH   | 2020-2024 |
| Jagadeesh                                     | AS   | 2021-2025 |
| Shard PM                                      | CV   | 2021-2025 |
| Shruthishree                                  | CH   | 2021-2025 |
| H P Manoj                                     | CSE  | 2021-2025 |
| Joshua Elias Alva                             | CSE  | 2021-2025 |
| Aditya Joshi                                  | ECE  | 2021-2025 |
| Shrinidhi Udupa                               | ECE  | 2021-2025 |
| Vijay Kiran                                   | ECE  | 2021-2025 |
| Mukul K                                       | ME   | 2021-2025 |
| Vardhan                                       | IEM  | 2021-2025 |
| Dhruv                                         | EIE  | 2022-2026 |
| Sushas                                        | ETE  | 2022-2026 |
| Shreesha                                      | EIE  | 2022-2026 |
| Afnan                                         | ETE  | 2022-2026 |
| Megha                                         | CH   | 2022-2026 |
| Hemanth                                       | CSE  | 2022-2026 |



---

**List of Contributors:** [**Contributors**](https://docs.google.com/spreadsheets/d/1CcoPOLFaWOJdxpLAZfO3Y8h9M2i830wRb3_0TwbtZvM/edit?usp=sharing)

---

### If you encounter any issues, please report them using the link below:

**[Report Issues](https://forms.gle/dKSctaXneaB1uTtW6)**


# Previous Year Question papers

## [Home](../main/index.md) | [Updates](../main/updates.md) | [Credits](../main/credits.md)

---
Dear user,

You can access through this RVCE link: [PYQP](http://172.16.44.10:8080/jspui/handle/123456789/207) within RVCE premises using college IP address, old semester examination question papers of both UG (RVCE autonomous) and PG (VTU) papers by giving appropriate keyword search. This can be accessed in any department & any system through college IP address ONLY so you gotta be connected to College WiFi.

---
**Note:** Some of the subjects old question papers (both UG & PG) may not have been uploaded.

If you are **UNABLE** to open the link, please follow the following procedure:

1. Log on to [www.rvce.edu.in](http://www.rvce.edu.in)
2. Click on "Library" on the side of the web page
3. Click on "Dspace@rvce"
---
Some of you may be aware of the procedure to access and download question papers.

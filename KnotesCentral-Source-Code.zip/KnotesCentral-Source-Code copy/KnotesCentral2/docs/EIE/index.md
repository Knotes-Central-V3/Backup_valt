# Electrical and Instrumentation Engineering

## [Home](../main/index.md) | [Updates](../main/updates.md) | [Credits](../main/credits.md)

---

# Course Material

| Year             | Link                                                                                              |
| --------------------------- | ------------------------------------------------------------------------------------------------- |
| Second Year                 | [Link](https://drive.google.com/drive/folders/18MmSKM_deFftfaq8TvzQPVWxMJlxJwG_?usp=sharing   )   |
| Third Year                  | [Link](https://drive.google.com/drive/folders/1Kkwh94l4uZ5QGi4lW70C8zs_4UbraFmt?usp=sharing  )   |
| Fourth Year                 | [Link](https://drive.google.com/drive/folders/1eFbP0pfb8ToKC7dZDtdVYpoyI3808_JO?usp=sharing   )   |

___
<p style="color:red; font-size:small;">
  Login Via RVCE Mail ID to Access the Notes !!
</p>
     
